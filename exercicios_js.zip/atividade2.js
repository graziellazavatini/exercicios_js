function faturamentoMensal(){
    let ganhoAnual = 0;
    let gastoAnual = 0;
    let prejuizo = false;

for (let i = 1; i <= 4; i++){
    let ganho = prompt("Digite o ganho bruto do mês " + i + " :");
    let gasto = prompt("Digite o gasto bruto do mês " + i + " :");
    ganhoAnual += parseFloat(ganho);
    //ganhoAnual = parseFloat(ganho) + ganhoAnual;
    gastoAnual += parseFloat(gasto);
    //gastoAnual = parseFloat(gasto) + gastoAnual;
}

let saldoFinanceiro = ganhoAnual - gastoAnual;

if(saldoFinanceiro < 0) {
    prejuizo = true;
}

alert("Ganho bruto anual: R$" + ganhoAnual);
alert("Gasto bruto anual: R$" + gastoAnual);
alert("Saldo financeiro anual: R$:" + saldoFinanceiro);

if (!prejuizo){
    alert("A receita líquida é de " + parseFloat(saldoFinanceiro) + " reais e a empresa teve lucro.")
} else {
    alert("A receita líquida é de " + parseFloat(saldoFinanceiro) + " reais e a empresa teve prejuízo.")
}
}