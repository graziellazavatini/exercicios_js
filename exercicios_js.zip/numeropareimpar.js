const CampoNumeroPI = document.getElementById("numeroPI");
const rotulo = document.getElementById("botaoPI");
let disponivel = false;

function TrocarRotulo() {
    disponivel = true;
    if (parseInt(campoNumeroPI.value) % 2 ==0){
        rotulo.innerHML = "<h2>Transformar em impar </h2>";
    } else {
        rotulo.innerHML = "<h2>Transformar em par </h2>";
    }
}
function InverterParImpar() {
    if(indiponivel) {
        return;
    }
    if (parseInt(campoNumeroPI.value) % 2 ==0){
        campoNumeroPI.value = parseInt(campoNumeroPI.value) + 1;
    } else {
        campoNumeroPI.value = parseInt(campoNumeroPI.value) - 1;
    }
}