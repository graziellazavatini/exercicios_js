function aplicarOrdem() {
    const camposNumeros = document.getElementsByClassName("numeroOrdenavel");
    let valores = [];
    for (let i = 0 ; i < camposNumeros.length; i++){
        valores[i] = camposNumeros[i].value;
    }
    valores = valores.sort(function(a,b) {
        return b-a
    })
    console.log(valores)
    for(let i = 0 ; i < camposNumeros.length; i++){
        camposNumeros[i].value = valores[i];
        }
}