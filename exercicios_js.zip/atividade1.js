/*function contagemRegressiva() {
    for(let i=10; i >=0; i--) {
        
        console.log(i);
        
    }
    console.log("Lançamento!");
}
contagemRegressiva()*/

function contagemRegressiva() {
    let contagem = 10;

    let sequencia = setInterval(
        function lancamento(){
            console.log(contagem);
            contagem--;
            //contagem = contagem - 1;
            if (contagem < 1){
                clearInterval(sequencia);
                console.log("Lançamento!");
            }
        }
   , 1000)
}