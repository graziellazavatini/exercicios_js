document.getElementById('payrollForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    
    var nome = document.getElementById('nome').value;
    var salario = parseFloat(document.getElementById('salario').value);
    var taxaINSS = 0.08;
    var inss = salario * taxaINSS;  
    var salarioLiquido = salario - inss;
    

    document.getElementById('nomeResultado').textContent = nome;
    document.getElementById('salarioBruto').textContent = salario.toFixed(2);
    document.getElementById('valorINSS').textContent = inss.toFixed(2);
    document.getElementById('salarioLiquido').textContent = salarioLiquido.toFixed(2);
    
  
    document.getElementById('resultado').classList.remove('hidden');
  });