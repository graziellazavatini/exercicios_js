document.getElementById("popup-trigger").addEventListener("mouseover", function() {
    document.getElementById("myPopup").style.display = "block";
});

document.getElementById("closePopup").addEventListener("click", function() {
    document.getElementById("myPopup").style.display = "none";
});

document.getElementById("myPopup").addEventListener("mouseleave", function() {
    document.getElementById("myPopup").style.display = "none";
});